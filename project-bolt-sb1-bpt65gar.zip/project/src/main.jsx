import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import './index.css'
import { AuthProvider } from './contexts/AuthContext.jsx'
import { AppointmentProvider } from './contexts/AppointmentContext.jsx'
import { NotificationProvider } from './contexts/NotificationContext.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <AppointmentProvider>
          <NotificationProvider>
            <App />
          </NotificationProvider>
        </AppointmentProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
)