import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FaCalendarAlt, FaFileMedical, FaPills, FaHeartbeat, FaStethoscope } from 'react-icons/fa'
import { useAppointments } from '../contexts/AppointmentContext'
import { useAuth } from '../contexts/AuthContext'
import UpcomingAppointment from '../components/dashboard/UpcomingAppointment'
import HealthMetricsChart from '../components/dashboard/HealthMetricsChart'
import MedicationReminder from '../components/dashboard/MedicationReminder'
import AppointmentScheduler from '../components/dashboard/AppointmentScheduler'

function Dashboard() {
  const { currentUser } = useAuth()
  const { getUpcomingAppointments } = useAppointments()
  const [upcomingAppointments, setUpcomingAppointments] = useState([])
  
  useEffect(() => {
    setUpcomingAppointments(getUpcomingAppointments().slice(0, 2))
  }, [getUpcomingAppointments])
  
  // Animation variants for staggered children
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  }

  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={container}
      className="max-w-7xl mx-auto"
    >
      {/* Welcome Banner */}
      <motion.div 
        variants={item} 
        className="bg-primary-600 rounded-xl p-6 text-white mb-6 shadow-soft overflow-hidden relative"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500 rounded-full transform translate-x-1/3 -translate-y-1/3 opacity-50" />
        <div className="relative z-10">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Welcome back, {currentUser?.name}</h1>
          <p className="opacity-90 max-w-xl">Your health dashboard is updated and ready. Here's a summary of your health activities and upcoming appointments.</p>
          
          <div className="mt-6 flex flex-wrap gap-3">
            <button className="bg-white text-primary-700 px-4 py-2 rounded-lg font-medium text-sm hover:bg-primary-50 transition-colors">
              Schedule Appointment
            </button>
            <button className="bg-primary-700 bg-opacity-30 text-white px-4 py-2 rounded-lg font-medium text-sm hover:bg-opacity-40 transition-colors">
              View Health Records
            </button>
          </div>
        </div>
      </motion.div>
      
      {/* Health Stats Overview */}
      <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded-xl shadow-soft flex items-center">
          <div className="p-3 bg-primary-100 rounded-lg mr-4">
            <FaHeartbeat className="text-primary-600 text-xl" />
          </div>
          <div>
            <p className="text-neutral-500 text-sm">Heart Rate</p>
            <h3 className="text-xl font-semibold">72 BPM</h3>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-xl shadow-soft flex items-center">
          <div className="p-3 bg-success-100 rounded-lg mr-4">
            <FaStethoscope className="text-success-600 text-xl" />
          </div>
          <div>
            <p className="text-neutral-500 text-sm">Blood Pressure</p>
            <h3 className="text-xl font-semibold">120/80</h3>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-xl shadow-soft flex items-center">
          <div className="p-3 bg-warning-100 rounded-lg mr-4">
            <FaPills className="text-warning-600 text-xl" />
          </div>
          <div>
            <p className="text-neutral-500 text-sm">Medications</p>
            <h3 className="text-xl font-semibold">3 Active</h3>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-xl shadow-soft flex items-center">
          <div className="p-3 bg-secondary-100 rounded-lg mr-4">
            <FaCalendarAlt className="text-secondary-600 text-xl" />
          </div>
          <div>
            <p className="text-neutral-500 text-sm">Appointments</p>
            <h3 className="text-xl font-semibold">{upcomingAppointments.length} Upcoming</h3>
          </div>
        </div>
      </motion.div>
      
      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <motion.div variants={item} className="lg:col-span-2 space-y-6">
          {/* Health Metrics Chart */}
          <div className="bg-white p-4 rounded-xl shadow-soft">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Health Metrics</h2>
              <select className="text-sm border border-neutral-300 rounded-md px-2 py-1">
                <option>Last 7 Days</option>
                <option>Last 30 Days</option>
                <option>Last 90 Days</option>
              </select>
            </div>
            <HealthMetricsChart />
          </div>
          
          {/* Upcoming Appointments */}
          <div className="bg-white p-4 rounded-xl shadow-soft">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Upcoming Appointments</h2>
              <a href="/appointments" className="text-primary-600 text-sm hover:underline">View All</a>
            </div>
            
            {upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAppointments.map((appointment) => (
                  <UpcomingAppointment 
                    key={appointment.id} 
                    appointment={appointment} 
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-neutral-500">
                <FaCalendarAlt className="mx-auto text-2xl mb-2 text-neutral-400" />
                <p>No upcoming appointments</p>
                <button className="mt-2 text-primary-600 font-medium hover:underline">
                  Schedule Now
                </button>
              </div>
            )}
          </div>
          
          {/* Recent Health Records */}
          <div className="bg-white p-4 rounded-xl shadow-soft">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Recent Health Records</h2>
              <a href="/health-records" className="text-primary-600 text-sm hover:underline">View All</a>
            </div>
            
            <div className="space-y-3">
              <div className="border border-neutral-200 rounded-lg p-3 hover:bg-neutral-50 transition-colors cursor-pointer">
                <div className="flex items-center">
                  <FaFileMedical className="text-primary-500 mr-3" />
                  <div>
                    <h4 className="font-medium">Blood Test Results</h4>
                    <p className="text-sm text-neutral-500">October 15, 2023</p>
                  </div>
                  <div className="ml-auto">
                    <span className="badge badge-primary">Lab Report</span>
                  </div>
                </div>
              </div>
              
              <div className="border border-neutral-200 rounded-lg p-3 hover:bg-neutral-50 transition-colors cursor-pointer">
                <div className="flex items-center">
                  <FaFileMedical className="text-primary-500 mr-3" />
                  <div>
                    <h4 className="font-medium">Annual Physical Checkup</h4>
                    <p className="text-sm text-neutral-500">September 22, 2023</p>
                  </div>
                  <div className="ml-auto">
                    <span className="badge badge-success">Report</span>
                  </div>
                </div>
              </div>
              
              <div className="border border-neutral-200 rounded-lg p-3 hover:bg-neutral-50 transition-colors cursor-pointer">
                <div className="flex items-center">
                  <FaFileMedical className="text-primary-500 mr-3" />
                  <div>
                    <h4 className="font-medium">Vaccination Record</h4>
                    <p className="text-sm text-neutral-500">August 10, 2023</p>
                  </div>
                  <div className="ml-auto">
                    <span className="badge badge-warning">Immunization</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Right Column */}
        <motion.div variants={item} className="space-y-6">
          {/* Quick Actions */}
          <div className="bg-white p-4 rounded-xl shadow-soft">
            <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-3">
              <button className="flex flex-col items-center p-3 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors">
                <FaCalendarAlt className="text-primary-600 text-xl mb-2" />
                <span className="text-sm font-medium">New Appointment</span>
              </button>
              
              <button className="flex flex-col items-center p-3 bg-success-50 rounded-lg hover:bg-success-100 transition-colors">
                <FaFileMedical className="text-success-600 text-xl mb-2" />
                <span className="text-sm font-medium">Upload Records</span>
              </button>
              
              <button className="flex flex-col items-center p-3 bg-warning-50 rounded-lg hover:bg-warning-100 transition-colors">
                <FaPills className="text-warning-600 text-xl mb-2" />
                <span className="text-sm font-medium">Medication Refill</span>
              </button>
              
              <button className="flex flex-col items-center p-3 bg-secondary-50 rounded-lg hover:bg-secondary-100 transition-colors">
                <FaStethoscope className="text-secondary-600 text-xl mb-2" />
                <span className="text-sm font-medium">Find Doctor</span>
              </button>
            </div>
          </div>
          
          {/* Medication Reminders */}
          <div className="bg-white p-4 rounded-xl shadow-soft">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Medication Reminders</h2>
              <a href="/medications" className="text-primary-600 text-sm hover:underline">Manage</a>
            </div>
            
            <MedicationReminder />
          </div>
          
          {/* Quick Appointment Scheduling */}
          <div className="bg-white p-4 rounded-xl shadow-soft">
            <h2 className="text-lg font-semibold mb-4">Quick Schedule</h2>
            <AppointmentScheduler />
          </div>
        </motion.div>
      </div>
    </motion.div>
  )
}

export default Dashboard