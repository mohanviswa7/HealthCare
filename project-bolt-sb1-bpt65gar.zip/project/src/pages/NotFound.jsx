import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

function NotFound() {
  return (
    <motion.div 
      className="min-h-screen bg-neutral-50 flex flex-col justify-center items-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center max-w-md">
        <div className="mb-6">
          <motion.div
            className="inline-block"
            animate={{ 
              y: [0, -10, 0],
              rotate: [0, 5, -5, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatType: "reverse"
            }}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#4F9FF0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-24 h-24">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
            </svg>
          </motion.div>
        </div>
        
        <h1 className="text-4xl font-bold text-neutral-800 mb-2">404</h1>
        <h2 className="text-2xl font-bold text-neutral-700 mb-4">Page Not Found</h2>
        <p className="text-neutral-600 mb-8">
          The page you are looking for doesn't exist or has been moved.
        </p>
        
        <Link 
          to="/" 
          className="btn btn-primary inline-block"
        >
          Return to Dashboard
        </Link>
      </div>
    </motion.div>
  )
}

export default NotFound