import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaEnvelope, FaSearch, FaUser, FaPaperPlane, FaPhoneAlt, FaVideo } from 'react-icons/fa'

function Messages() {
  const [activeConversation, setActiveConversation] = useState('1')
  const [message, setMessage] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  
  // Mock conversations data
  const conversations = [
    {
      id: '1',
      provider: {
        id: 'dr-smith',
        name: 'Dr. Smith',
        specialty: 'Cardiologist',
        avatar: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        status: 'online'
      },
      unread: 2,
      lastMessage: {
        text: 'Your test results look good. Your cholesterol levels have improved since your last visit.',
        timestamp: '10:32 AM',
        sender: 'provider'
      }
    },
    {
      id: '2',
      provider: {
        id: 'dr-johnson',
        name: 'Dr. Johnson',
        specialty: 'Dermatologist',
        avatar: 'https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        status: 'offline'
      },
      unread: 0,
      lastMessage: {
        text: 'Please send a photo of the affected area so I can see how it\'s healing.',
        timestamp: 'Yesterday',
        sender: 'provider'
      }
    },
    {
      id: '3',
      provider: {
        id: 'dr-patel',
        name: 'Dr. Patel',
        specialty: 'Neurologist',
        avatar: 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        status: 'offline'
      },
      unread: 0,
      lastMessage: {
        text: 'I\'ll need to see you for a follow-up appointment in 3 months.',
        timestamp: 'Oct 10',
        sender: 'provider'
      }
    }
  ]
  
  // Mock messages data for each conversation
  const messagesByConversation = {
    '1': [
      {
        id: '1-1',
        text: 'Hello Dr. Smith, I wanted to ask about my recent test results.',
        timestamp: '10:15 AM',
        sender: 'user'
      },
      {
        id: '1-2',
        text: 'Hello! I have reviewed your test results. Everything looks good overall.',
        timestamp: '10:20 AM',
        sender: 'provider'
      },
      {
        id: '1-3',
        text: 'Your cholesterol levels have improved since your last visit. Keep up with the diet and exercise regimen we discussed.',
        timestamp: '10:32 AM',
        sender: 'provider'
      }
    ],
    '2': [
      {
        id: '2-1',
        text: 'Dr. Johnson, the rash seems to be getting better but it\'s still itchy.',
        timestamp: 'Yesterday, 2:30 PM',
        sender: 'user'
      },
      {
        id: '2-2',
        text: 'That\'s good to hear that it\'s improving. The itchiness is normal as it heals. Continue with the prescribed cream.',
        timestamp: 'Yesterday, 3:15 PM',
        sender: 'provider'
      },
      {
        id: '2-3',
        text: 'Please send a photo of the affected area so I can see how it\'s healing.',
        timestamp: 'Yesterday, 3:16 PM',
        sender: 'provider'
      }
    ],
    '3': [
      {
        id: '3-1',
        text: 'Dr. Patel, I\'ve been experiencing fewer headaches since starting the new medication.',
        timestamp: 'Oct 10, 9:45 AM',
        sender: 'user'
      },
      {
        id: '3-2',
        text: 'That\'s excellent news! The medication seems to be working as expected. Have you noticed any side effects?',
        timestamp: 'Oct 10, 10:30 AM',
        sender: 'provider'
      },
      {
        id: '3-3',
        text: 'I\'ll need to see you for a follow-up appointment in 3 months.',
        timestamp: 'Oct 10, 10:32 AM',
        sender: 'provider'
      }
    ]
  }
  
  // Filter conversations based on search query
  const filteredConversations = conversations.filter(conversation => 
    conversation.provider.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    conversation.provider.specialty.toLowerCase().includes(searchQuery.toLowerCase())
  )
  
  const handleSendMessage = (e) => {
    e.preventDefault()
    
    if (!message.trim()) return
    
    // In a real app, this would send the message to the server
    console.log('Sending message:', message)
    setMessage('')
  }
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const item = {
    hidden: { opacity: 0 },
    show: { opacity: 1 }
  }
  
  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={container}
      className="h-[calc(100vh-12rem)] max-w-6xl mx-auto"
    >
      <motion.div variants={item} className="mb-4">
        <h1 className="text-2xl font-bold text-neutral-800">Messages</h1>
        <p className="text-neutral-500">Communicate securely with your healthcare providers</p>
      </motion.div>
      
      <motion.div 
        variants={item} 
        className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full"
      >
        {/* Conversations list */}
        <div className="bg-white rounded-xl shadow-soft overflow-hidden md:col-span-1">
          <div className="p-3 border-b border-neutral-200">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FaSearch className="text-neutral-400" />
              </div>
              <input
                type="text"
                placeholder="Search conversations"
                className="pl-10 pr-4 py-2 rounded-lg border border-neutral-300 w-full focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <div className="overflow-y-auto h-[calc(100%-60px)]">
            {filteredConversations.length > 0 ? (
              filteredConversations.map((conversation) => (
                <div
                  key={conversation.id}
                  className={`p-3 border-b border-neutral-200 cursor-pointer transition-colors ${
                    activeConversation === conversation.id
                      ? 'bg-primary-50'
                      : 'hover:bg-neutral-50'
                  }`}
                  onClick={() => setActiveConversation(conversation.id)}
                >
                  <div className="flex items-start">
                    <div className="relative mr-3">
                      <img
                        src={conversation.provider.avatar}
                        alt={conversation.provider.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      {conversation.provider.status === 'online' && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-success-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>
                    
                    <div className="flex-grow min-w-0">
                      <div className="flex justify-between items-start">
                        <h3 className="font-medium text-neutral-800 truncate">
                          {conversation.provider.name}
                        </h3>
                        <span className="text-xs text-neutral-500 whitespace-nowrap ml-2">
                          {conversation.lastMessage.timestamp}
                        </span>
                      </div>
                      
                      <p className="text-sm text-neutral-500 truncate">
                        {conversation.provider.specialty}
                      </p>
                      
                      <div className="flex justify-between items-center mt-1">
                        <p className="text-sm text-neutral-600 truncate max-w-[180px]">
                          {conversation.lastMessage.sender === 'provider' ? '' : 'You: '}
                          {conversation.lastMessage.text}
                        </p>
                        
                        {conversation.unread > 0 && (
                          <span className="bg-primary-500 text-white text-xs min-w-[20px] h-5 rounded-full flex items-center justify-center">
                            {conversation.unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-neutral-500">
                <FaEnvelope className="mx-auto text-2xl mb-2 text-neutral-400" />
                <p>No conversations found</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Conversation detail */}
        <div className="bg-white rounded-xl shadow-soft overflow-hidden md:col-span-2 flex flex-col">
          {activeConversation && conversations.find(c => c.id === activeConversation) ? (
            <>
              {/* Conversation header */}
              <div className="p-4 border-b border-neutral-200 flex justify-between items-center">
                <div className="flex items-center">
                  <img
                    src={conversations.find(c => c.id === activeConversation).provider.avatar}
                    alt={conversations.find(c => c.id === activeConversation).provider.name}
                    className="w-10 h-10 rounded-full object-cover mr-3"
                  />
                  <div>
                    <h3 className="font-medium">
                      {conversations.find(c => c.id === activeConversation).provider.name}
                    </h3>
                    <p className="text-xs text-neutral-500">
                      {conversations.find(c => c.id === activeConversation).provider.specialty}
                      {' • '}
                      {conversations.find(c => c.id === activeConversation).provider.status === 'online' 
                        ? <span className="text-success-500">Online</span>
                        : <span className="text-neutral-500">Offline</span>
                      }
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <button className="p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 transition-colors">
                    <FaPhoneAlt className="text-neutral-600" />
                  </button>
                  <button className="p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 transition-colors">
                    <FaVideo className="text-neutral-600" />
                  </button>
                </div>
              </div>
              
              {/* Messages */}
              <div className="flex-grow overflow-y-auto p-4 bg-neutral-50">
                <div className="space-y-4">
                  {messagesByConversation[activeConversation].map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {msg.sender === 'provider' && (
                        <img
                          src={conversations.find(c => c.id === activeConversation).provider.avatar}
                          alt={conversations.find(c => c.id === activeConversation).provider.name}
                          className="w-8 h-8 rounded-full object-cover mr-2 self-end"
                        />
                      )}
                      
                      <div>
                        <div 
                          className={`max-w-xs p-3 rounded-lg ${
                            msg.sender === 'user'
                              ? 'bg-primary-500 text-white rounded-br-none'
                              : 'bg-white text-neutral-800 rounded-bl-none shadow-soft'
                          }`}
                        >
                          <p className="text-sm">{msg.text}</p>
                        </div>
                        <p className="text-xs text-neutral-500 mt-1">
                          {msg.timestamp}
                        </p>
                      </div>
                      
                      {msg.sender === 'user' && (
                        <div className="w-8 h-8 rounded-full bg-neutral-200 flex items-center justify-center ml-2 self-end">
                          <FaUser className="text-neutral-500 text-sm" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Message input */}
              <div className="p-3 border-t border-neutral-200">
                <form onSubmit={handleSendMessage} className="flex">
                  <input
                    type="text"
                    placeholder="Type a message..."
                    className="flex-grow px-3 py-2 border border-neutral-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  />
                  <button
                    type="submit"
                    className="bg-primary-500 text-white px-4 py-2 rounded-r-lg hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
                  >
                    <FaPaperPlane />
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex-grow flex flex-col items-center justify-center p-4 text-center">
              <FaEnvelope className="text-4xl text-neutral-300 mb-4" />
              <h3 className="text-lg font-medium text-neutral-700 mb-2">No conversation selected</h3>
              <p className="text-neutral-500 max-w-md">
                Select a conversation from the list to view messages or start a new conversation with one of your healthcare providers.
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}

export default Messages