import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaFileMedical, FaFileUpload, FaSearch, FaFilter } from 'react-icons/fa'

function HealthRecords() {
  const [filter, setFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  
  // Mock health records data
  const healthRecords = [
    {
      id: '1',
      title: 'Blood Test Results',
      date: 'October 15, 2023',
      provider: 'Dr. Smith',
      type: 'lab',
      description: 'Complete blood count (CBC), metabolic panel, lipid panel, and thyroid function tests.'
    },
    {
      id: '2',
      title: 'Annual Physical Checkup',
      date: 'September 22, 2023',
      provider: 'Dr. Johnson',
      type: 'report',
      description: 'Comprehensive physical examination including vital signs, body composition, and general health assessment.'
    },
    {
      id: '3',
      title: 'Vaccination Record',
      date: 'August 10, 2023',
      provider: 'Dr. Williams',
      type: 'immunization',
      description: 'COVID-19 booster vaccination administered. No adverse reactions noted.'
    },
    {
      id: '4',
      title: 'Cardiac Assessment',
      date: 'July 5, 2023',
      provider: 'Dr. Chen',
      type: 'report',
      description: 'Electrocardiogram (ECG) and cardiac stress test results with cardiologist evaluation.'
    },
    {
      id: '5',
      title: 'X-Ray Results',
      date: 'June 12, 2023',
      provider: 'Dr. Garcia',
      type: 'imaging',
      description: 'Chest X-ray showing normal lung fields with no abnormalities detected.'
    }
  ]
  
  // Filter health records based on type and search query
  const filteredRecords = healthRecords.filter(record => {
    const matchesFilter = filter === 'all' || record.type === filter
    const matchesSearch = record.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         record.provider.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesFilter && matchesSearch
  })
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  }
  
  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={container}
      className="max-w-5xl mx-auto"
    >
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-800">Health Records</h1>
          <p className="text-neutral-500">Access and manage your medical records</p>
        </div>
        
        <button className="mt-4 md:mt-0 btn btn-primary inline-flex items-center">
          <FaFileUpload className="mr-2" />
          Upload New Record
        </button>
      </motion.div>
      
      <motion.div variants={item} className="bg-white rounded-xl shadow-soft p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          {/* Search input */}
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaSearch className="text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search records by title or doctor"
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-300 w-full focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {/* Filter dropdown */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaFilter className="text-neutral-400" />
            </div>
            <select
              className="pl-10 pr-10 py-2 rounded-lg border border-neutral-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 appearance-none bg-white"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Records</option>
              <option value="lab">Lab Results</option>
              <option value="report">Reports</option>
              <option value="imaging">Imaging</option>
              <option value="immunization">Immunizations</option>
            </select>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
        </div>
      </motion.div>
      
      {/* Records list */}
      <div className="space-y-4">
        {filteredRecords.length > 0 ? (
          filteredRecords.map((record) => (
            <motion.div
              key={record.id}
              variants={item}
              className="bg-white rounded-xl shadow-soft p-4 hover:shadow-medium transition-shadow cursor-pointer"
            >
              <div className="flex items-start">
                <div className="p-3 bg-primary-100 rounded-lg mr-4">
                  <FaFileMedical className="text-primary-600 text-xl" />
                </div>
                
                <div className="flex-grow">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">{record.title}</h3>
                      <p className="text-neutral-500 text-sm">{record.date} • {record.provider}</p>
                    </div>
                    
                    <div className="mt-2 md:mt-0">
                      {record.type === 'lab' && (
                        <span className="badge badge-primary">Lab Results</span>
                      )}
                      {record.type === 'report' && (
                        <span className="badge badge-success">Report</span>
                      )}
                      {record.type === 'imaging' && (
                        <span className="badge badge-secondary">Imaging</span>
                      )}
                      {record.type === 'immunization' && (
                        <span className="badge badge-warning">Immunization</span>
                      )}
                    </div>
                  </div>
                  
                  <p className="mt-2 text-neutral-600">{record.description}</p>
                  
                  <div className="mt-4 flex gap-2">
                    <button className="btn-outline btn py-1 px-3 text-xs">View</button>
                    <button className="btn-outline btn py-1 px-3 text-xs">Download</button>
                    <button className="btn-outline btn py-1 px-3 text-xs">Share</button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <motion.div 
            variants={item} 
            className="bg-white rounded-xl shadow-soft p-8 text-center"
          >
            <FaFileMedical className="mx-auto text-3xl text-neutral-400 mb-2" />
            <h3 className="text-lg font-medium text-neutral-700 mb-1">No records found</h3>
            <p className="text-neutral-500 mb-4">
              {searchQuery 
                ? `No records match your search for "${searchQuery}"`
                : filter !== 'all'
                  ? `You don't have any ${filter} records`
                  : "You don't have any health records yet"
              }
            </p>
            {!searchQuery && (
              <button className="btn btn-primary">
                Upload Your First Record
              </button>
            )}
          </motion.div>
        )}
      </div>
    </motion.div>
  )
}

export default HealthRecords