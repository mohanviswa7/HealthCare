import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaPills, FaPlus, FaSearch, FaClipboardCheck, FaHistory } from 'react-icons/fa'

function Medications() {
  const [activeTab, setActiveTab] = useState('current')
  const [searchQuery, setSearchQuery] = useState('')
  
  // Mock medications data
  const allMedications = {
    current: [
      {
        id: '1',
        name: 'Lisinopril',
        dosage: '10mg',
        schedule: 'Once daily',
        time: 'Morning',
        instructions: 'Take with food',
        refills: 2,
        nextRefill: '2023-11-15',
        prescribedBy: 'Dr. Smith',
        startDate: '2023-05-10'
      },
      {
        id: '2',
        name: 'Metformin',
        dosage: '500mg',
        schedule: 'Twice daily',
        time: 'Morning/Evening',
        instructions: 'Take with meals',
        refills: 3,
        nextRefill: '2023-12-01',
        prescribedBy: 'Dr. Johnson',
        startDate: '2023-04-22'
      },
      {
        id: '3',
        name: 'Atorvastatin',
        dosage: '20mg',
        schedule: 'Once daily',
        time: 'Evening',
        instructions: 'Take at bedtime',
        refills: 1,
        nextRefill: '2023-10-28',
        prescribedBy: 'Dr. Smith',
        startDate: '2023-06-15'
      }
    ],
    history: [
      {
        id: '4',
        name: 'Amoxicillin',
        dosage: '500mg',
        schedule: 'Three times daily',
        instructions: 'Take until complete',
        prescribedBy: 'Dr. Williams',
        startDate: '2023-01-10',
        endDate: '2023-01-24',
        reason: 'Course completed'
      },
      {
        id: '5',
        name: 'Prednisone',
        dosage: '10mg',
        schedule: 'Once daily, tapering dose',
        instructions: 'Follow tapering schedule',
        prescribedBy: 'Dr. Garcia',
        startDate: '2023-03-05',
        endDate: '2023-03-19',
        reason: 'Treatment completed'
      }
    ]
  }
  
  // Filter medications based on search query
  const filteredMedications = {
    current: allMedications.current.filter(med => 
      med.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      med.prescribedBy.toLowerCase().includes(searchQuery.toLowerCase())
    ),
    history: allMedications.history.filter(med => 
      med.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      med.prescribedBy.toLowerCase().includes(searchQuery.toLowerCase())
    )
  }
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  }
  
  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={container}
      className="max-w-5xl mx-auto"
    >
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-800">Medications</h1>
          <p className="text-neutral-500">Manage your prescriptions and medication schedule</p>
        </div>
        
        <button className="mt-4 md:mt-0 btn btn-primary inline-flex items-center">
          <FaPlus className="mr-2" />
          Add Medication
        </button>
      </motion.div>
      
      <motion.div variants={item} className="bg-white rounded-xl shadow-soft p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          {/* Search input */}
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaSearch className="text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search medications or doctors"
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-300 w-full focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </motion.div>
      
      {/* Tabs */}
      <motion.div variants={item} className="flex border-b border-neutral-200 mb-6">
        <button
          onClick={() => setActiveTab('current')}
          className={`py-2 px-4 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'current'
              ? 'text-primary-600 border-primary-500'
              : 'text-neutral-500 border-transparent hover:text-neutral-700 hover:border-neutral-300'
          }`}
        >
          <FaClipboardCheck className="inline mr-2" />
          Current Medications
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`py-2 px-4 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'history'
              ? 'text-primary-600 border-primary-500'
              : 'text-neutral-500 border-transparent hover:text-neutral-700 hover:border-neutral-300'
          }`}
        >
          <FaHistory className="inline mr-2" />
          Medication History
        </button>
      </motion.div>
      
      {/* Medications list */}
      <div className="space-y-4">
        {activeTab === 'current' && (
          filteredMedications.current.length > 0 ? (
            filteredMedications.current.map((medication) => (
              <motion.div
                key={medication.id}
                variants={item}
                className="bg-white rounded-xl shadow-soft p-4 hover:shadow-medium transition-shadow"
              >
                <div className="flex flex-col md:flex-row">
                  <div className="p-3 bg-warning-100 rounded-lg mr-4 mb-4 md:mb-0 self-start">
                    <FaPills className="text-warning-600 text-xl" />
                  </div>
                  
                  <div className="flex-grow">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">{medication.name} {medication.dosage}</h3>
                        <p className="text-neutral-500 text-sm">
                          {medication.schedule} • {medication.time}
                        </p>
                      </div>
                      
                      <div className="mt-2 md:mt-0">
                        <span className="badge badge-success">Active</span>
                        <span className="badge badge-primary ml-2">{medication.refills} Refills Left</span>
                      </div>
                    </div>
                    
                    <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-neutral-500">Instructions:</span> {medication.instructions}
                      </div>
                      <div>
                        <span className="text-neutral-500">Prescribed by:</span> {medication.prescribedBy}
                      </div>
                      <div>
                        <span className="text-neutral-500">Started:</span> {medication.startDate}
                      </div>
                      <div>
                        <span className="text-neutral-500">Next refill:</span> {medication.nextRefill}
                      </div>
                    </div>
                    
                    <div className="mt-4 flex gap-2">
                      <button className="btn-primary btn py-1.5 px-3 text-sm">Request Refill</button>
                      <button className="btn-outline btn py-1.5 px-3 text-sm">Set Reminder</button>
                      <button className="btn-outline btn py-1.5 px-3 text-sm">View Details</button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <motion.div 
              variants={item} 
              className="bg-white rounded-xl shadow-soft p-8 text-center"
            >
              <FaPills className="mx-auto text-3xl text-neutral-400 mb-2" />
              <h3 className="text-lg font-medium text-neutral-700 mb-1">No current medications found</h3>
              <p className="text-neutral-500 mb-4">
                {searchQuery 
                  ? `No medications match your search for "${searchQuery}"`
                  : "You don't have any current medications"
                }
              </p>
              {!searchQuery && (
                <button className="btn btn-primary">
                  Add Medication
                </button>
              )}
            </motion.div>
          )
        )}
        
        {activeTab === 'history' && (
          filteredMedications.history.length > 0 ? (
            filteredMedications.history.map((medication) => (
              <motion.div
                key={medication.id}
                variants={item}
                className="bg-white rounded-xl shadow-soft p-4"
              >
                <div className="flex flex-col md:flex-row">
                  <div className="p-3 bg-neutral-100 rounded-lg mr-4 mb-4 md:mb-0 self-start">
                    <FaPills className="text-neutral-500 text-xl" />
                  </div>
                  
                  <div className="flex-grow">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">{medication.name} {medication.dosage}</h3>
                        <p className="text-neutral-500 text-sm">
                          {medication.schedule}
                        </p>
                      </div>
                      
                      <div className="mt-2 md:mt-0">
                        <span className="badge badge-neutral">Inactive</span>
                      </div>
                    </div>
                    
                    <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-neutral-500">Instructions:</span> {medication.instructions}
                      </div>
                      <div>
                        <span className="text-neutral-500">Prescribed by:</span> {medication.prescribedBy}
                      </div>
                      <div>
                        <span className="text-neutral-500">Start date:</span> {medication.startDate}
                      </div>
                      <div>
                        <span className="text-neutral-500">End date:</span> {medication.endDate}
                      </div>
                      <div className="md:col-span-2">
                        <span className="text-neutral-500">Reason ended:</span> {medication.reason}
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <button className="btn-outline btn py-1.5 px-3 text-sm">View Details</button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <motion.div 
              variants={item} 
              className="bg-white rounded-xl shadow-soft p-8 text-center"
            >
              <FaHistory className="mx-auto text-3xl text-neutral-400 mb-2" />
              <h3 className="text-lg font-medium text-neutral-700 mb-1">No medication history found</h3>
              <p className="text-neutral-500 mb-4">
                {searchQuery 
                  ? `No medications match your search for "${searchQuery}"`
                  : "You don't have any past medications"
                }
              </p>
            </motion.div>
          )
        )}
      </div>
    </motion.div>
  )
}

export default Medications