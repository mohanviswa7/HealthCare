import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaSearch, FaFilter, FaStar, FaMapMarkerAlt, FaPhone, FaEnvelope, FaCalendarAlt } from 'react-icons/fa'

function Providers() {
  const [searchQuery, setSearchQuery] = useState('')
  const [specialty, setSpecialty] = useState('all')
  const [view, setView] = useState('grid')
  
  // Mock providers data
  const providers = [
    {
      id: 'dr-smith',
      name: 'Dr. Sarah Smith',
      specialty: 'Cardiologist',
      avatar: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      rating: 4.8,
      reviews: 125,
      location: 'Boston Medical Center',
      distance: '2.3 miles',
      availability: 'Next available: Tomorrow',
      acceptingNewPatients: true,
      education: 'Harvard Medical School',
      languages: ['English', 'Spanish'],
      phone: '(617) 555-1234',
      email: 'dr.smith@example.com'
    },
    {
      id: 'dr-johnson',
      name: 'Dr. Michael Johnson',
      specialty: 'Dermatologist',
      avatar: 'https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      rating: 4.6,
      reviews: 98,
      location: 'Skin Health Center',
      distance: '3.5 miles',
      availability: 'Next available: Thursday',
      acceptingNewPatients: true,
      education: 'Johns Hopkins University',
      languages: ['English'],
      phone: '(617) 555-2345',
      email: 'dr.johnson@example.com'
    },
    {
      id: 'dr-patel',
      name: 'Dr. Priya Patel',
      specialty: 'Neurologist',
      avatar: 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      rating: 4.9,
      reviews: 156,
      location: 'Neurology Partners',
      distance: '1.8 miles',
      availability: 'Next available: Friday',
      acceptingNewPatients: true,
      education: 'Stanford University',
      languages: ['English', 'Hindi', 'Gujarati'],
      phone: '(617) 555-3456',
      email: 'dr.patel@example.com'
    },
    {
      id: 'dr-rodriguez',
      name: 'Dr. Carlos Rodriguez',
      specialty: 'Orthopedic Surgeon',
      avatar: 'https://images.pexels.com/photos/4167541/pexels-photo-4167541.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      rating: 4.7,
      reviews: 112,
      location: 'Advanced Orthopedics',
      distance: '4.2 miles',
      availability: 'Next available: Next Tuesday',
      acceptingNewPatients: false,
      education: 'University of California, San Francisco',
      languages: ['English', 'Spanish'],
      phone: '(617) 555-4567',
      email: 'dr.rodriguez@example.com'
    },
    {
      id: 'dr-thompson',
      name: 'Dr. Emily Thompson',
      specialty: 'Pediatrician',
      avatar: 'https://images.pexels.com/photos/5214958/pexels-photo-5214958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      rating: 4.9,
      reviews: 210,
      location: "Children's Wellness Center",
      distance: '2.1 miles',
      availability: 'Next available: Tomorrow',
      acceptingNewPatients: true,
      education: 'Baylor College of Medicine',
      languages: ['English', 'French'],
      phone: '(617) 555-5678',
      email: 'dr.thompson@example.com'
    },
    {
      id: 'dr-williams',
      name: 'Dr. James Williams',
      specialty: 'Psychiatrist',
      avatar: 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      rating: 4.5,
      reviews: 87,
      location: 'Mind & Wellness Clinic',
      distance: '3.0 miles',
      availability: 'Next available: Monday',
      acceptingNewPatients: true,
      education: 'Columbia University',
      languages: ['English'],
      phone: '(617) 555-6789',
      email: 'dr.williams@example.com'
    }
  ]
  
  // Get unique specialties for filter dropdown
  const specialties = ['all', ...new Set(providers.map(provider => provider.specialty))]
  
  // Filter providers based on search query and specialty
  const filteredProviders = providers.filter(provider => {
    const matchesSearch = provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         provider.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         provider.location.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesSpecialty = specialty === 'all' || provider.specialty === specialty
    return matchesSearch && matchesSpecialty
  })
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  }
  
  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={container}
      className="max-w-6xl mx-auto"
    >
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-800">Healthcare Providers</h1>
          <p className="text-neutral-500">Find and connect with healthcare professionals</p>
        </div>
      </motion.div>
      
      <motion.div variants={item} className="bg-white rounded-xl shadow-soft p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          {/* Search input */}
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaSearch className="text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search by name, specialty, or location"
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-300 w-full focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {/* Specialty filter */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaFilter className="text-neutral-400" />
            </div>
            <select
              className="pl-10 pr-10 py-2 rounded-lg border border-neutral-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 appearance-none bg-white"
              value={specialty}
              onChange={(e) => setSpecialty(e.target.value)}
            >
              <option value="all">All Specialties</option>
              {specialties.filter(s => s !== 'all').map((specialty) => (
                <option key={specialty} value={specialty}>{specialty}</option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
          
          {/* View toggle */}
          <div className="flex rounded-lg overflow-hidden border border-neutral-300">
            <button
              className={`py-2 px-3 ${view === 'grid' ? 'bg-primary-500 text-white' : 'bg-white text-neutral-600'}`}
              onClick={() => setView('grid')}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
            </button>
            <button
              className={`py-2 px-3 ${view === 'list' ? 'bg-primary-500 text-white' : 'bg-white text-neutral-600'}`}
              onClick={() => setView('list')}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </motion.div>
      
      {/* Providers Grid/List */}
      {view === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProviders.length > 0 ? (
            filteredProviders.map((provider) => (
              <motion.div
                key={provider.id}
                variants={item}
                className="bg-white rounded-xl shadow-soft overflow-hidden hover:shadow-medium transition-shadow"
              >
                <div className="h-32 bg-primary-100 relative">
                  {provider.acceptingNewPatients && (
                    <div className="absolute top-4 right-4 bg-success-500 text-white text-xs py-1 px-2 rounded-full">
                      Accepting New Patients
                    </div>
                  )}
                </div>
                
                <div className="px-4 pt-0 pb-4 relative">
                  <div className="flex justify-center -mt-16 mb-3">
                    <img 
                      src={provider.avatar}
                      alt={provider.name}
                      className="w-32 h-32 rounded-full border-4 border-white object-cover"
                    />
                  </div>
                  
                  <div className="text-center mb-4">
                    <h3 className="text-xl font-semibold">{provider.name}</h3>
                    <p className="text-neutral-500">{provider.specialty}</p>
                    
                    <div className="flex items-center justify-center mt-1">
                      <FaStar className="text-yellow-400 mr-1" />
                      <span className="font-medium">{provider.rating}</span>
                      <span className="text-neutral-500 text-sm ml-1">({provider.reviews} reviews)</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm text-neutral-600 mb-4">
                    <div className="flex items-start">
                      <FaMapMarkerAlt className="text-primary-500 mt-1 mr-2" />
                      <div>
                        <p>{provider.location}</p>
                        <p className="text-neutral-500">{provider.distance}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center">
                      <FaCalendarAlt className="text-primary-500 mr-2" />
                      <p>{provider.availability}</p>
                    </div>
                    
                    <div className="flex items-center">
                      <FaPhone className="text-primary-500 mr-2" />
                      <p>{provider.phone}</p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button className="btn btn-primary flex-grow">Book Appointment</button>
                    <button className="btn btn-outline flex-grow">View Profile</button>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <motion.div 
              variants={item} 
              className="bg-white rounded-xl shadow-soft p-8 text-center col-span-full"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-neutral-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-lg font-medium text-neutral-700 mb-1">No providers found</h3>
              <p className="text-neutral-500 mb-4">
                {searchQuery || specialty !== 'all'
                  ? `No providers match your search criteria`
                  : "No healthcare providers available at this time"
                }
              </p>
              {(searchQuery || specialty !== 'all') && (
                <button 
                  className="btn btn-primary"
                  onClick={() => {
                    setSearchQuery('')
                    setSpecialty('all')
                  }}
                >
                  Clear Filters
                </button>
              )}
            </motion.div>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredProviders.length > 0 ? (
            filteredProviders.map((provider) => (
              <motion.div
                key={provider.id}
                variants={item}
                className="bg-white rounded-xl shadow-soft p-4 hover:shadow-medium transition-shadow"
              >
                <div className="flex flex-col md:flex-row">
                  <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-6 text-center md:text-left">
                    <img 
                      src={provider.avatar}
                      alt={provider.name}
                      className="w-24 h-24 rounded-full object-cover mx-auto md:mx-0"
                    />
                    
                    <div className="mt-2 flex items-center justify-center md:justify-start">
                      <FaStar className="text-yellow-400 mr-1" />
                      <span className="font-medium">{provider.rating}</span>
                      <span className="text-neutral-500 text-sm ml-1">({provider.reviews})</span>
                    </div>
                  </div>
                  
                  <div className="flex-grow">
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between">
                      <div>
                        <h3 className="text-xl font-semibold">{provider.name}</h3>
                        <p className="text-neutral-500">{provider.specialty}</p>
                      </div>
                      
                      <div className="mt-2 md:mt-0 text-right">
                        {provider.acceptingNewPatients ? (
                          <span className="badge badge-success">Accepting New Patients</span>
                        ) : (
                          <span className="badge badge-neutral">Not Accepting New Patients</span>
                        )}
                      </div>
                    </div>
                    
                    <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center">
                        <FaMapMarkerAlt className="text-primary-500 mr-2" />
                        <span>{provider.location} ({provider.distance})</span>
                      </div>
                      
                      <div className="flex items-center">
                        <FaCalendarAlt className="text-primary-500 mr-2" />
                        <span>{provider.availability}</span>
                      </div>
                      
                      <div className="flex items-center">
                        <FaPhone className="text-primary-500 mr-2" />
                        <span>{provider.phone}</span>
                      </div>
                      
                      <div className="flex items-center">
                        <FaEnvelope className="text-primary-500 mr-2" />
                        <span>{provider.email}</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex gap-2">
                      <button className="btn btn-primary">Book Appointment</button>
                      <button className="btn btn-outline">View Profile</button>
                      <button className="btn btn-outline">Send Message</button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <motion.div 
              variants={item} 
              className="bg-white rounded-xl shadow-soft p-8 text-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-neutral-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-lg font-medium text-neutral-700 mb-1">No providers found</h3>
              <p className="text-neutral-500 mb-4">
                {searchQuery || specialty !== 'all'
                  ? `No providers match your search criteria`
                  : "No healthcare providers available at this time"
                }
              </p>
              {(searchQuery || specialty !== 'all') && (
                <button 
                  className="btn btn-primary"
                  onClick={() => {
                    setSearchQuery('')
                    setSpecialty('all')
                  }}
                >
                  Clear Filters
                </button>
              )}
            </motion.div>
          )}
        </div>
      )}
    </motion.div>
  )
}

export default Providers