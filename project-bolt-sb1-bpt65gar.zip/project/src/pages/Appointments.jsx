import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaCalendarPlus, FaFilter, FaSearch } from 'react-icons/fa'
import { useAppointments } from '../contexts/AppointmentContext'
import UpcomingAppointment from '../components/dashboard/UpcomingAppointment'

function Appointments() {
  const { appointments } = useAppointments()
  const [filter, setFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  
  // Filter appointments based on status and search query
  const filteredAppointments = appointments.filter(appointment => {
    const matchesFilter = filter === 'all' || appointment.status === filter
    const matchesSearch = appointment.providerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         appointment.providerSpecialty.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesFilter && matchesSearch
  })
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  }
  
  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={container}
      className="max-w-5xl mx-auto"
    >
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-800">Appointments</h1>
          <p className="text-neutral-500">Manage your upcoming and past appointments</p>
        </div>
        
        <button className="mt-4 md:mt-0 btn btn-primary inline-flex items-center">
          <FaCalendarPlus className="mr-2" />
          Schedule New Appointment
        </button>
      </motion.div>
      
      <motion.div variants={item} className="bg-white rounded-xl shadow-soft p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          {/* Search input */}
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaSearch className="text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search by doctor or specialty"
              className="pl-10 pr-4 py-2 rounded-lg border border-neutral-300 w-full focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {/* Filter dropdown */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaFilter className="text-neutral-400" />
            </div>
            <select
              className="pl-10 pr-10 py-2 rounded-lg border border-neutral-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 appearance-none bg-white"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Appointments</option>
              <option value="confirmed">Confirmed</option>
              <option value="pending">Pending</option>
              <option value="cancelled">Cancelled</option>
            </select>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
        </div>
      </motion.div>
      
      <motion.div variants={item} className="space-y-4">
        {filteredAppointments.length > 0 ? (
          filteredAppointments.map((appointment) => (
            <UpcomingAppointment 
              key={appointment.id} 
              appointment={appointment} 
            />
          ))
        ) : (
          <div className="bg-white rounded-xl shadow-soft p-8 text-center">
            <FaCalendarPlus className="mx-auto text-3xl text-neutral-400 mb-2" />
            <h3 className="text-lg font-medium text-neutral-700 mb-1">No appointments found</h3>
            <p className="text-neutral-500 mb-4">
              {searchQuery 
                ? `No appointments match your search for "${searchQuery}"`
                : filter !== 'all'
                  ? `You don't have any ${filter} appointments`
                  : "You don't have any appointments yet"
              }
            </p>
            {!searchQuery && (
              <button className="btn btn-primary">
                Schedule Your First Appointment
              </button>
            )}
          </div>
        )}
      </motion.div>
    </motion.div>
  )
}

export default Appointments