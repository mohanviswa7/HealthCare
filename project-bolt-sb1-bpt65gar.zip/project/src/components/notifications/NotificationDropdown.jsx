import { motion } from 'framer-motion'
import { useNotifications } from '../../contexts/NotificationContext'
import NotificationItem from './NotificationItem'

function NotificationDropdown({ onClose }) {
  const { notifications, markAllAsRead } = useNotifications()

  return (
    <motion.div
      className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-medium border border-neutral-200 z-40 max-h-96 overflow-y-auto"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      transition={{ duration: 0.2 }}
    >
      <div className="p-3 border-b border-neutral-200 flex justify-between items-center">
        <h3 className="font-medium">Notifications</h3>
        <button
          onClick={markAllAsRead}
          className="text-xs text-primary-600 hover:text-primary-700"
        >
          Mark all as read
        </button>
      </div>
      
      <div className="divide-y divide-neutral-200">
        {notifications.length > 0 ? (
          notifications.map(notification => (
            <NotificationItem 
              key={notification.id} 
              notification={notification} 
              onClose={onClose}
            />
          ))
        ) : (
          <div className="p-4 text-center text-neutral-500">
            No notifications
          </div>
        )}
      </div>
      
      <div className="p-2 border-t border-neutral-200">
        <button
          className="w-full text-center text-sm text-primary-600 hover:text-primary-700 p-2"
        >
          View all notifications
        </button>
      </div>
    </motion.div>
  )
}

export default NotificationDropdown