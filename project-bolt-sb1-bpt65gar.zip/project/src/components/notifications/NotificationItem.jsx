import { FaCalendarAlt, FaFileMedical, FaPills } from 'react-icons/fa'
import { useNotifications } from '../../contexts/NotificationContext'

function NotificationItem({ notification, onClose }) {
  const { markAsRead } = useNotifications()
  
  const handleClick = () => {
    if (!notification.read) {
      markAsRead(notification.id)
    }
    onClose()
  }
  
  // Determine icon based on notification type
  const getIcon = () => {
    switch(notification.type) {
      case 'appointment':
        return <FaCalendarAlt className="text-primary-500" />
      case 'results':
        return <FaFileMedical className="text-success-500" />
      case 'medication':
        return <FaPills className="text-warning-500" />
      default:
        return null
    }
  }
  
  return (
    <div 
      className={`p-3 hover:bg-neutral-50 cursor-pointer transition-colors ${notification.read ? 'bg-white' : 'bg-blue-50'}`}
      onClick={handleClick}
    >
      <div className="flex items-start">
        <div className="mt-0.5 mr-3 p-2 rounded-full bg-neutral-100">
          {getIcon()}
        </div>
        <div>
          <h4 className="font-medium text-sm">{notification.title}</h4>
          <p className="text-xs text-neutral-600 mt-1">{notification.message}</p>
          <p className="text-xs text-neutral-400 mt-1">{notification.date}</p>
        </div>
      </div>
    </div>
  )
}

export default NotificationItem