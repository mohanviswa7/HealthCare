import React from 'react'

function Footer() {
  return (
    <footer className="bg-white border-t border-neutral-200 py-4 px-6 text-sm text-neutral-500">
      <div className="flex flex-col md:flex-row justify-between items-center">
        <div>
          <p>&copy; {new Date().getFullYear()} MediCare. All rights reserved.</p>
        </div>
        <div className="flex space-x-4 mt-2 md:mt-0">
          <a href="#" className="hover:text-primary-600 transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-primary-600 transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-primary-600 transition-colors">Contact Us</a>
        </div>
      </div>
    </footer>
  )
}

export default Footer