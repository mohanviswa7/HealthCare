import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FaBars, FaBell, FaSignOutAlt } from 'react-icons/fa'
import { useAuth } from '../../contexts/AuthContext'
import { useNotifications } from '../../contexts/NotificationContext'
import NotificationDropdown from '../notifications/NotificationDropdown'

function Topbar({ toggleSidebar }) {
  const { currentUser, logout } = useAuth()
  const { notifications, unreadCount } = useNotifications()
  const [showNotifications, setShowNotifications] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)

  const handleLogout = () => {
    logout()
  }

  return (
    <header className="h-16 bg-white border-b border-neutral-200 px-4 flex items-center justify-between">
      {/* Left side - Menu toggle & search */}
      <div className="flex items-center">
        <button 
          onClick={toggleSidebar}
          className="p-2 mr-2 rounded-full hover:bg-neutral-100"
        >
          <FaBars className="text-neutral-500" />
        </button>
        
        <div className="hidden md:block relative">
          <input
            type="text"
            placeholder="Search..."
            className="pl-10 pr-4 py-2 rounded-lg bg-neutral-100 border-none focus:ring-2 focus:ring-primary-500 w-64"
          />
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-400 absolute left-3 top-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>
      
      {/* Right side - Notifications & user menu */}
      <div className="flex items-center space-x-4">
        {/* Notifications */}
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-full hover:bg-neutral-100 relative"
          >
            <FaBell className="text-neutral-500" />
            {unreadCount > 0 && (
              <span className="absolute top-0 right-0 bg-error-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full transform translate-x-1 -translate-y-1">
                {unreadCount}
              </span>
            )}
          </button>
          
          <AnimatePresence>
            {showNotifications && (
              <NotificationDropdown 
                onClose={() => setShowNotifications(false)} 
              />
            )}
          </AnimatePresence>
        </div>
        
        {/* User menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center space-x-2"
          >
            <img 
              src={currentUser?.avatar} 
              alt={currentUser?.name}
              className="w-8 h-8 rounded-full object-cover"
            />
            <span className="hidden md:block text-sm font-medium">
              {currentUser?.name}
            </span>
          </button>
          
          <AnimatePresence>
            {showUserMenu && (
              <motion.div
                className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-medium border border-neutral-200 z-40"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="p-3 border-b border-neutral-200">
                  <p className="text-sm font-medium">{currentUser?.name}</p>
                  <p className="text-xs text-neutral-500">{currentUser?.email}</p>
                </div>
                <div className="p-2">
                  <button
                    onClick={handleLogout}
                    className="flex items-center space-x-2 w-full text-left px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-100 rounded-md"
                  >
                    <FaSignOutAlt className="text-neutral-500" />
                    <span>Logout</span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  )
}

export default Topbar