import { NavLink } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useAuth } from '../../contexts/AuthContext'
import { 
  FaHome, 
  FaCalendarAlt, 
  FaFileMedical, 
  FaPills, 
  FaCommentMedical, 
  FaUserMd,
  FaTimes 
} from 'react-icons/fa'

function Sidebar({ isOpen, toggleSidebar, isMobile }) {
  const { currentUser } = useAuth()
  
  const navLinks = [
    { path: '/', icon: <FaHome />, label: 'Dashboard' },
    { path: '/appointments', icon: <FaCalendarAlt />, label: 'Appointments' },
    { path: '/health-records', icon: <FaFileMedical />, label: 'Health Records' },
    { path: '/medications', icon: <FaPills />, label: 'Medications' },
    { path: '/messages', icon: <FaCommentMedical />, label: 'Messages' },
    { path: '/providers', icon: <FaUserMd />, label: 'Providers' }
  ]

  // Animation variants
  const sidebarVariants = {
    open: {
      x: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 30
      }
    },
    closed: {
      x: isMobile ? "-100%" : "0%",
      width: isMobile ? "0px" : "80px",
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 30
      }
    }
  }

  const navItemVariants = {
    open: {
      opacity: 1,
      x: 0,
      transition: {
        delay: 0.2
      }
    },
    closed: {
      opacity: isMobile ? 0 : 1,
      x: isMobile ? -20 : 0
    }
  }

  return (
    <motion.aside
      className={`bg-white border-r border-neutral-200 shadow-sm z-30 ${isMobile ? 'fixed h-full' : 'relative'}`}
      initial={isMobile ? "closed" : "open"}
      animate={isOpen ? "open" : "closed"}
      variants={sidebarVariants}
    >
      {/* Logo and close button */}
      <div className="h-16 border-b border-neutral-200 flex items-center justify-between px-4">
        <motion.div 
          className="flex items-center space-x-2"
          variants={navItemVariants}
        >
          <div className="w-8 h-8 rounded-md bg-primary-500 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
            </svg>
          </div>
          <h1 className="text-xl font-bold text-neutral-800">MediCare</h1>
        </motion.div>
        
        {isMobile && (
          <button 
            onClick={toggleSidebar}
            className="p-2 rounded-full hover:bg-neutral-100"
          >
            <FaTimes className="text-neutral-500" />
          </button>
        )}
      </div>
      
      {/* User info */}
      <div className="p-4 border-b border-neutral-200">
        <motion.div 
          className="flex items-center space-x-3"
          variants={navItemVariants}
        >
          <img 
            src={currentUser?.avatar} 
            alt={currentUser?.name}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <h3 className="font-medium text-neutral-800">{currentUser?.name}</h3>
            <p className="text-sm text-neutral-500">Patient</p>
          </div>
        </motion.div>
      </div>
      
      {/* Navigation */}
      <nav className="p-2">
        <ul className="space-y-1">
          {navLinks.map((link) => (
            <li key={link.path}>
              <NavLink 
                to={link.path}
                className={({ isActive }) => 
                  `flex items-center px-4 py-2.5 rounded-lg transition-all duration-200 ${
                    isActive 
                      ? 'bg-primary-50 text-primary-600' 
                      : 'text-neutral-600 hover:bg-neutral-100'
                  }`
                }
              >
                <span className="text-lg">{link.icon}</span>
                <motion.span 
                  className="ml-3 font-medium"
                  variants={navItemVariants}
                >
                  {link.label}
                </motion.span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </motion.aside>
  )
}

export default Sidebar