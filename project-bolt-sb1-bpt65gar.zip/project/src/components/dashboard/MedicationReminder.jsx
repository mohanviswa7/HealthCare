import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaCheck, FaPills } from 'react-icons/fa'

function MedicationReminder() {
  // Mock medication data
  const [medications, setMedications] = useState([
    { 
      id: '1', 
      name: 'Lisinopril', 
      dosage: '10mg', 
      frequency: 'Once daily', 
      time: 'Morning',
      instructions: 'Take with food',
      taken: false
    },
    { 
      id: '2', 
      name: 'Metformin', 
      dosage: '500mg', 
      frequency: 'Twice daily', 
      time: 'Morning/Evening',
      instructions: 'Take with meals',
      taken: false
    },
    { 
      id: '3', 
      name: 'Atorvastatin', 
      dosage: '20mg', 
      frequency: 'Once daily', 
      time: 'Evening',
      instructions: 'Take at bedtime',
      taken: true
    }
  ])
  
  const toggleMedication = (id) => {
    setMedications(prev => 
      prev.map(med => 
        med.id === id ? { ...med, taken: !med.taken } : med
      )
    )
  }
  
  return (
    <div className="space-y-3">
      {medications.map((medication) => (
        <motion.div 
          key={medication.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`border rounded-lg p-3 flex items-center ${
            medication.taken 
              ? 'bg-success-50 border-success-200' 
              : 'border-neutral-200 hover:border-primary-300'
          } transition-colors`}
        >
          <div className="mr-3">
            <button
              onClick={() => toggleMedication(medication.id)}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                medication.taken 
                  ? 'bg-success-500 text-white' 
                  : 'bg-neutral-100 text-neutral-400 hover:bg-primary-100 hover:text-primary-500'
              }`}
            >
              {medication.taken ? <FaCheck /> : <FaPills />}
            </button>
          </div>
          
          <div className="flex-grow">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium">{medication.name} {medication.dosage}</h4>
                <p className="text-sm text-neutral-500">{medication.frequency} • {medication.time}</p>
              </div>
              {medication.taken && (
                <span className="text-xs text-success-600 font-medium">Taken</span>
              )}
            </div>
            <p className="text-xs text-neutral-500 mt-1">{medication.instructions}</p>
          </div>
        </motion.div>
      ))}
    </div>
  )
}

export default MedicationReminder