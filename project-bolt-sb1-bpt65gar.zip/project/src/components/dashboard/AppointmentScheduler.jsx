import { useState } from 'react'
import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import './calendar-overrides.css'

function AppointmentScheduler() {
  const [date, setDate] = useState(new Date())
  const [selectedTime, setSelectedTime] = useState(null)
  
  // Mock available time slots
  const availableTimes = [
    { id: '1', time: '09:00', available: true },
    { id: '2', time: '10:00', available: false },
    { id: '3', time: '11:00', available: true },
    { id: '4', time: '13:30', available: true },
    { id: '5', time: '14:30', available: false },
    { id: '6', time: '15:30', available: true },
    { id: '7', time: '16:30', available: true },
  ]
  
  const handleDateChange = (newDate) => {
    setDate(newDate)
    setSelectedTime(null)
  }
  
  const handleTimeSelect = (timeId) => {
    setSelectedTime(timeId)
  }
  
  return (
    <div>
      {/* Custom styled calendar */}
      <div className="mb-4">
        <Calendar 
          onChange={handleDateChange} 
          value={date} 
          minDate={new Date()} 
          className="rounded-lg border-none shadow-none w-full"
        />
      </div>
      
      {/* Time slots */}
      <div className="mb-4">
        <h3 className="text-sm font-medium text-neutral-600 mb-2">Available Times</h3>
        <div className="grid grid-cols-3 gap-2">
          {availableTimes.map((slot) => (
            <button
              key={slot.id}
              onClick={() => slot.available && handleTimeSelect(slot.id)}
              className={`text-sm py-2 px-1 rounded-md transition-colors ${
                !slot.available
                  ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                  : selectedTime === slot.id
                    ? 'bg-primary-500 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-primary-100'
              }`}
              disabled={!slot.available}
            >
              {slot.time}
            </button>
          ))}
        </div>
      </div>
      
      {/* Submit button */}
      <button
        className={`btn w-full ${
          selectedTime ? 'btn-primary' : 'btn-outline cursor-not-allowed opacity-70'
        }`}
        disabled={!selectedTime}
      >
        Schedule Appointment
      </button>
    </div>
  )
}

export default AppointmentScheduler