import { parseISO, format } from 'date-fns'
import { motion } from 'framer-motion'
import { FaCalendarAlt, FaClock, FaMapMarkerAlt, FaVideo } from 'react-icons/fa'

function UpcomingAppointment({ appointment }) {
  const appointmentDate = parseISO(`${appointment.date}T${appointment.time}`)
  
  return (
    <motion.div 
      className="border border-neutral-200 rounded-lg p-4 hover:border-primary-300 transition-all cursor-pointer"
      whileHover={{ y: -2, boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)' }}
    >
      <div className="flex flex-col md:flex-row md:items-center">
        {/* Provider avatar */}
        <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-4">
          <img 
            src={appointment.providerAvatar} 
            alt={appointment.providerName}
            className="w-14 h-14 rounded-full object-cover border-2 border-neutral-200"
          />
        </div>
        
        {/* Appointment details */}
        <div className="flex-grow">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h3 className="font-semibold">{appointment.providerName}</h3>
              <p className="text-sm text-neutral-500">{appointment.providerSpecialty}</p>
            </div>
            
            <div className="mt-2 md:mt-0">
              {appointment.status === 'confirmed' ? (
                <span className="badge badge-success">Confirmed</span>
              ) : (
                <span className="badge badge-warning">Pending</span>
              )}
              
              {appointment.type === 'virtual' ? (
                <span className="badge badge-primary ml-2">Virtual</span>
              ) : (
                <span className="badge badge-secondary ml-2">In-person</span>
              )}
            </div>
          </div>
          
          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2">
            <div className="flex items-center text-sm">
              <FaCalendarAlt className="text-primary-500 mr-2" />
              <span>{format(appointmentDate, 'MMMM d, yyyy')}</span>
            </div>
            
            <div className="flex items-center text-sm">
              <FaClock className="text-primary-500 mr-2" />
              <span>{format(appointmentDate, 'h:mm a')} ({appointment.duration} min)</span>
            </div>
            
            {appointment.type === 'in-person' && appointment.location && (
              <div className="flex items-center text-sm md:col-span-2">
                <FaMapMarkerAlt className="text-primary-500 mr-2" />
                <span>{appointment.location}</span>
              </div>
            )}
          </div>
          
          <div className="mt-3 flex flex-wrap gap-2">
            {appointment.type === 'virtual' && (
              <button className="btn btn-primary flex items-center">
                <FaVideo className="mr-1" />
                Join Call
              </button>
            )}
            <button className="btn btn-outline">Reschedule</button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export default UpcomingAppointment