import { createContext, useContext, useState } from 'react'
import { addDays, format, parseISO } from 'date-fns'

const AppointmentContext = createContext()

export function useAppointments() {
  return useContext(AppointmentContext)
}

export function AppointmentProvider({ children }) {
  const today = new Date()
  
  // Mock data for appointments
  const [appointments, setAppointments] = useState([
    {
      id: '1',
      providerId: 'dr-smith',
      providerName: 'Dr. Smith',
      providerSpecialty: 'Cardiologist',
      providerAvatar: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      date: format(addDays(today, 2), 'yyyy-MM-dd'),
      time: '10:00',
      duration: 30,
      status: 'confirmed',
      type: 'in-person',
      location: 'Cardiology Center, 123 Medical Lane',
      notes: 'Annual heart checkup'
    },
    {
      id: '2',
      providerId: 'dr-johnson',
      providerName: 'Dr. Johnson',
      providerSpecialty: 'Dermatologist',
      providerAvatar: 'https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      date: format(addDays(today, 5), 'yyyy-MM-dd'),
      time: '14:30',
      duration: 45,
      status: 'confirmed',
      type: 'virtual',
      location: null,
      notes: 'Follow-up on skin treatment'
    },
    {
      id: '3',
      providerId: 'dr-patel',
      providerName: 'Dr. Patel',
      providerSpecialty: 'Neurologist',
      providerAvatar: 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      date: format(addDays(today, 10), 'yyyy-MM-dd'),
      time: '09:15',
      duration: 60,
      status: 'pending',
      type: 'in-person',
      location: 'Neurology Department, 456 Health Blvd',
      notes: 'Initial consultation'
    }
  ])

  // Add a new appointment
  const addAppointment = (appointment) => {
    setAppointments(prev => [...prev, { 
      id: Date.now().toString(),
      ...appointment
    }])
  }

  // Update an existing appointment
  const updateAppointment = (id, updatedData) => {
    setAppointments(prev => 
      prev.map(appointment => 
        appointment.id === id ? { ...appointment, ...updatedData } : appointment
      )
    )
  }

  // Cancel an appointment
  const cancelAppointment = (id) => {
    setAppointments(prev => 
      prev.map(appointment => 
        appointment.id === id ? { ...appointment, status: 'cancelled' } : appointment
      )
    )
  }

  // Get upcoming appointments
  const getUpcomingAppointments = () => {
    const today = new Date()
    return appointments.filter(appointment => {
      const appointmentDate = parseISO(`${appointment.date}T${appointment.time}`)
      return appointmentDate > today && appointment.status !== 'cancelled'
    }).sort((a, b) => {
      const dateA = parseISO(`${a.date}T${a.time}`)
      const dateB = parseISO(`${b.date}T${b.time}`)
      return dateA - dateB
    })
  }

  const value = {
    appointments,
    addAppointment,
    updateAppointment,
    cancelAppointment,
    getUpcomingAppointments
  }

  return (
    <AppointmentContext.Provider value={value}>
      {children}
    </AppointmentContext.Provider>
  )
}