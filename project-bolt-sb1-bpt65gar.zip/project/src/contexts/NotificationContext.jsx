import { createContext, useContext, useState, useEffect } from 'react'
import { addDays, format } from 'date-fns'

const NotificationContext = createContext()

export function useNotifications() {
  return useContext(NotificationContext)
}

export function NotificationProvider({ children }) {
  const [notifications, setNotifications] = useState([])
  const [unreadCount, setUnreadCount] = useState(0)

  // Generate some mock notifications on mount
  useEffect(() => {
    const today = new Date()
    const mockNotifications = [
      {
        id: '1',
        title: 'Appointment Confirmation',
        message: 'Your appointment with Dr. Smith has been confirmed for tomorrow at 10:00 AM.',
        type: 'appointment',
        date: format(new Date(), 'yyyy-MM-dd HH:mm'),
        read: false
      },
      {
        id: '2',
        title: 'Lab Results Available',
        message: 'Your recent blood work results are now available. Please check your health records.',
        type: 'results',
        date: format(addDays(today, -1), 'yyyy-MM-dd HH:mm'),
        read: false
      },
      {
        id: '3',
        title: 'Medication Reminder',
        message: 'Remember to take your Lisinopril medication today.',
        type: 'medication',
        date: format(addDays(today, -2), 'yyyy-MM-dd HH:mm'),
        read: true
      }
    ]
    
    setNotifications(mockNotifications)
    setUnreadCount(mockNotifications.filter(n => !n.read).length)
  }, [])

  // Add a new notification
  const addNotification = (notification) => {
    const newNotification = {
      id: Date.now().toString(),
      date: format(new Date(), 'yyyy-MM-dd HH:mm'),
      read: false,
      ...notification
    }
    setNotifications(prev => [newNotification, ...prev])
    setUnreadCount(prev => prev + 1)
  }

  // Mark a notification as read
  const markAsRead = (id) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    )
    setUnreadCount(prev => prev - 1)
  }

  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    )
    setUnreadCount(0)
  }

  // Delete a notification
  const deleteNotification = (id) => {
    const notification = notifications.find(n => n.id === id)
    setNotifications(prev => prev.filter(n => n.id !== id))
    if (!notification.read) {
      setUnreadCount(prev => prev - 1)
    }
  }

  const value = {
    notifications,
    unreadCount,
    addNotification,
    markAsRead,
    markAllAsRead,
    deleteNotification
  }

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  )
}