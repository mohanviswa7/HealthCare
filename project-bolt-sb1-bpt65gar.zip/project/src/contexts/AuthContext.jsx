import { createContext, useContext, useState, useEffect } from 'react'

// In a real app, you would use a proper authentication service
// This is a simplified mock implementation
const AuthContext = createContext()

export function useAuth() {
  return useContext(AuthContext)
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null)
  const [loading, setLoading] = useState(true)

  // Simulate checking if user is already logged in
  useEffect(() => {
    const user = localStorage.getItem('healthcareUser')
    if (user) {
      setCurrentUser(JSON.parse(user))
    }
    setLoading(false)
  }, [])

  // Login function
  const login = (email, password) => {
    // In a real app, this would make an API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Mock user data
        const user = {
          id: '123456',
          name: 'John Doe',
          email,
          avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
        }
        setCurrentUser(user)
        localStorage.setItem('healthcareUser', JSON.stringify(user))
        resolve(user)
      }, 1000)
    })
  }

  // Register function
  const register = (name, email, password) => {
    // In a real app, this would make an API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Mock user data
        const user = {
          id: '123456',
          name,
          email,
          avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
        }
        setCurrentUser(user)
        localStorage.setItem('healthcareUser', JSON.stringify(user))
        resolve(user)
      }, 1000)
    })
  }

  // Logout function
  const logout = () => {
    localStorage.removeItem('healthcareUser')
    setCurrentUser(null)
  }

  const value = {
    currentUser,
    login,
    register,
    logout,
    loading
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}