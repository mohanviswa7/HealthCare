import { Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import Layout from './components/layout/Layout'
import Dashboard from './pages/Dashboard'
import Appointments from './pages/Appointments'
import HealthRecords from './pages/HealthRecords'
import Medications from './pages/Medications'
import Messages from './pages/Messages'
import Providers from './pages/Providers'
import Login from './pages/Login'
import Register from './pages/Register'
import NotFound from './pages/NotFound'
import ProtectedRoute from './components/auth/ProtectedRoute'
import { useAuth } from './contexts/AuthContext'
import LoadingScreen from './components/ui/LoadingScreen'

function App() {
  const location = useLocation()
  const { currentUser, loading } = useAuth()

  if (loading) {
    return <LoadingScreen />
  }

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        <Route element={<ProtectedRoute />}>
          <Route element={<Layout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/appointments" element={<Appointments />} />
            <Route path="/health-records" element={<HealthRecords />} />
            <Route path="/medications" element={<Medications />} />
            <Route path="/messages" element={<Messages />} />
            <Route path="/providers" element={<Providers />} />
          </Route>
        </Route>
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AnimatePresence>
  )
}

export default App